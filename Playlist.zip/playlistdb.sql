-- phpMyAdmin SQL Dump
-- version 4.7.9
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Dec 15, 2018 at 07:30 PM
-- Server version: 10.1.31-MariaDB
-- PHP Version: 7.2.3

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET AUTOCOMMIT = 0;
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `playlistdb`
--
CREATE DATABASE IF NOT EXISTS `playlistdb` DEFAULT CHARACTER SET utf8 COLLATE utf8_general_ci;
USE `playlistdb`;

-- --------------------------------------------------------

--
-- Table structure for table `categorycodemovies`
--

CREATE TABLE `categorycodemovies` (
  `categoryCodeID` int(11) NOT NULL,
  `categoryName` varchar(30) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `categorycodemovies`
--

INSERT INTO `categorycodemovies` (`categoryCodeID`, `categoryName`) VALUES
(2, 'Autos & Vehicles'),
(9, 'Comedy'),
(15, 'Education'),
(13, 'Entertainment'),
(1, 'Film & Animation'),
(7, 'Gaming'),
(14, 'Howto & Style'),
(3, 'Music'),
(12, 'News & Politics'),
(17, 'Nonprofits & Activism'),
(8, 'People & Blogs'),
(4, 'Pets & Animals'),
(16, 'Science & Technology'),
(5, 'Sports'),
(6, 'Travel & Events');

-- --------------------------------------------------------

--
-- Table structure for table `movies`
--

CREATE TABLE `movies` (
  `MovieID` int(11) NOT NULL,
  `UserID` int(11) NOT NULL,
  `Title` varchar(100) NOT NULL,
  `Description` varchar(300) NOT NULL,
  `CategoryCode` int(11) NOT NULL,
  `Link` varchar(300) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `movies`
--

INSERT INTO `movies` (`MovieID`, `UserID`, `Title`, `Description`, `CategoryCode`, `Link`) VALUES
(2, 1, 'אור גדול', 'reference work on the World Wide Web,[3][4][5] and is one of the most popular websites by Alexa rank.[6] It is owned and supported by the Wikimedia Foundation, a non-profit organization that operates on money it receives from donors.[7][8][9]  Wikipedia was launched on January 15, 2001, by Jimmy Wal', 3, 'https://www.youtube.com/watch?v=jeU9Sbq0D0A'),
(3, 1, '12', 'kladsssssssssssssss alskddddddddddddddddddddd klasddddddddddddddd kalsddddddddddddd klasdddddddddddd lkasddddddddd', 3, 'https://www.youtube.com/watch?v=jeU9Sbq0D0A'),
(5, 1, '123', '12', 1, 'https://www.youtube.com/watch?v=XefS9XGkH5s'),
(6, 1, 'kdsk', 'kdl', 4, 'https://www.youtube.com/watch?v=XefS9XGkH5s'),
(7, 1, '356', '', 1, 'https://www.youtube.com/watch?v=XefS9XGkH5s'),
(8, 1, '43', '', 1, 'https://www.youtube.com/watch?v=XefS9XGkH5s'),
(9, 1, '653', '', 9, 'https://www.youtube.com/watch?v=XefS9XGkH5s'),
(10, 1, '12', '', 4, 'https://www.youtube.com/watch?v=XefS9XGkH5s'),
(11, 3, 'אור גדול', 'שירים נחמדים', 3, 'https://www.youtube.com/watch?v=jeU9Sbq0D0A'),
(12, 3, 'שאריות של  החיים', 'שירים יפים', 3, 'https://www.youtube.com/watch?v=xYYYctLmnt4'),
(13, 3, 'הולך נגד הרוח', '', 3, 'https://www.youtube.com/watch?v=zP26VkIL81c');

-- --------------------------------------------------------

--
-- Table structure for table `users`
--

CREATE TABLE `users` (
  `UserID` int(11) NOT NULL,
  `FirstName` varchar(30) NOT NULL,
  `LastName` varchar(30) NOT NULL,
  `UserName` varchar(50) NOT NULL,
  `Password` varchar(100) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `users`
--

INSERT INTO `users` (`UserID`, `FirstName`, `LastName`, `UserName`, `Password`) VALUES
(1, 'David', 'David', 'david', '7110eda4d09e062aa5e4a390b0a572ac0d2c0220'),
(2, 'Ofir', 'Houbara', 'ofir', '7110eda4d09e062aa5e4a390b0a572ac0d2c0220'),
(3, 'lizet', 'houbara', 'lizet', '011c945f30ce2cbafc452f39840f025693339c42');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `categorycodemovies`
--
ALTER TABLE `categorycodemovies`
  ADD PRIMARY KEY (`categoryCodeID`),
  ADD UNIQUE KEY `categoryName` (`categoryName`);

--
-- Indexes for table `movies`
--
ALTER TABLE `movies`
  ADD PRIMARY KEY (`MovieID`),
  ADD KEY `UserID` (`UserID`),
  ADD KEY `CategoryCode` (`CategoryCode`);

--
-- Indexes for table `users`
--
ALTER TABLE `users`
  ADD PRIMARY KEY (`UserID`),
  ADD UNIQUE KEY `UserName` (`UserName`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `categorycodemovies`
--
ALTER TABLE `categorycodemovies`
  MODIFY `categoryCodeID` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=18;

--
-- AUTO_INCREMENT for table `movies`
--
ALTER TABLE `movies`
  MODIFY `MovieID` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=15;

--
-- AUTO_INCREMENT for table `users`
--
ALTER TABLE `users`
  MODIFY `UserID` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;

--
-- Constraints for dumped tables
--

--
-- Constraints for table `movies`
--
ALTER TABLE `movies`
  ADD CONSTRAINT `movies_ibfk_1` FOREIGN KEY (`CategoryCode`) REFERENCES `categorycodemovies` (`categoryCodeID`) ON DELETE CASCADE ON UPDATE CASCADE,
  ADD CONSTRAINT `movies_ibfk_2` FOREIGN KEY (`UserID`) REFERENCES `users` (`UserID`) ON DELETE CASCADE ON UPDATE CASCADE;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
