<!DOCTYPE html>
<?php
session_start();
if (isset($_SESSION["username"])) {
    $username = $_SESSION["username"];
} else {
    $username = null;
}
?>

<html>
    <head>
        <meta charset="UTF-8">
        <title></title>
        <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.1.3/css/bootstrap.min.css" integrity="sha384-MCw98/SFnGE8fJT3GXwEOngsV7Zt27NXFoaoApmYm81iuXoPkFOJwJ8ERdknLPMO" crossorigin="anonymous">
        <link rel="stylesheet" href="https://use.fontawesome.com/releases/v5.5.0/css/all.css" integrity="sha384-B4dIYHKNBt8Bc12p+WXckhzcICo0wtJAoU8YZTY5qE0Id1GSseTk6S+L3BlXeVIU" crossorigin="anonymous">

        <link rel="stylesheet" href="css/style.css">
        <link href="https://fonts.googleapis.com/css?family=Gamja+Flower" rel="stylesheet">
        <script src="js/index.js"></script>
    </head>
    <body id="hompePageBody">

        <br>
        <div class="container-fluid" id="hompePageContainer">
            <div class="row" >

                <div class="col-12" id="mainPageTitle">
                    <button id="musicButton" onclick="playAudio()" class="far fa-pause-circle btn btn-danger"></button>
                    <iframe id="iframeSilence" src="assests/audio/1-second-of-silence.mp3" allow="autoplay"></iframe>
                    <audio  id="audio" src="assests/audio/Shape Of My Heart (Saxophone Cover).mp3" autoplay="true" loop preload="auto" autobuffer></audio>                   

                    <h1 id="head">My private Playlist</h1>
                </div>
            </div>
            <div class="row" id="mainPage" >
                <div class="col-12 center" >
                    <p>My private Playlist is the best place to create a playlist with any YouTube link </p>
                </div>
                <div class="offset-md-3 col-6 center" id="homePageForm">
                    <?php
                    if ($username == null) {
                        echo "<p>New user? Sign up to create your account</p>
                    <a href='html/register.php' class='btn btn-primary'>Sign-up</a>
                    <p>Already have an account? Log in</p>
                    <a href='html/login.php' class='btn btn-success'>Log-in</a>";
                    } else {
                        echo "<p>Hello $username</p>
                    <a href='html/logout.php' class='btn btn-success'>Log-out</a>
                    <p></p>
                    <a href='html/playlist.php' class='btn btn-primary'>Back to my playlist</a>";
                    }
                    ?>  
                </div>
            </div>

            <div id="container">
            </div>
        </div>
    </body>
</html>
