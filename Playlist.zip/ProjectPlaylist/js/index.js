var ajax;
var ajax1;

function myAjax(url, callback, method = 'get') {
    var ajax = new XMLHttpRequest();
    ajax.open(method, url, true);
    ajax.onreadystatechange = function () {
        if (ajax.readyState == 4 && ajax.status == 200) {
            if (ajax.responseText) {
                var json = JSON.parse(ajax.responseText);
                callback(json);
            }
        }
    }
    ajax.send();
}


function createCategoriesMoviesTableUI(callback) {

    if (ajax1.readyState == 4) {

        if (ajax1.status == 200) {

            if ((ajax1.responseText != "undefined") && (ajax1.responseText != "")) {
                callback()
            }
        } else {
            alert(ajax1.status + " --> " + ajax1.statusText);
        }
    }
}

//creat ajax for categories movies
function getCategoriesMoviesTable(callback) {

    var callbackCategoriesMovies = function (categoriesMovies) {

        var select = document.getElementById("categoryCode");
        if (select.childElementCount <= 1) {

            for (var i = 0; i < categoriesMovies.length; i++) {
                var option = document.createElement("option");
                option.innerHTML = categoriesMovies[i].categoryName;
                option.setAttribute("value", categoriesMovies[i].categoryCode);
                select.appendChild(option);
            }
        }
        if (callback != null) {
            callback();
        }

    }

    myAjax('../php/API.php?command=getCategoriesMoviesTable', callbackCategoriesMovies);
}


//create the playlist by onload the playlist.php
function getPlaylist() {
    var url = "../php/API.php?command=getPlaylist&offset=";
    ajax = new XMLHttpRequest();
    ajax.open("GET", url, true);
    ajax.onreadystatechange = createUI;
    ajax.send();
}


//add new movie to the playlist
function addMovieToPlaylist() {

    var titleBox = document.getElementById("title");
    var descriptionBox = document.getElementById("description");
    var categoryCodeSelect = document.getElementById("categoryCode");
    var linkBox = document.getElementById("link");

    var title = titleBox.value;
    var description = descriptionBox.value;
    var categoryCode = categoryCodeSelect[categoryCodeSelect.selectedIndex].value;
    var link = linkBox.value;

    document.getElementById("errorMessage").innerHTML = "";
    titleBox.style.backgroundColor = "";
    categoryCodeSelect.style.backgroundColor = "";
    linkBox.style.backgroundColor = "";

    if (!emptyInputValidation(titleBox, title, "Title")) {
        return false;
    }

    if (categoryCode === categoryCodeSelect.children[0].value) {
        document.getElementById("errorMessage").innerHTML = "Category name is missing!";
        categoryCodeSelect.style.backgroundColor = "red";
        return false;
    }

    if (!emptyInputValidation(linkBox, link, "YouTube link")) {
        return false;
    }

    if (!link.match(/^(?:https?:\/\/)?(?:www\.)?(?:youtu\.be\/|youtube\.com\/(?:embed\/|v\/|watch\?v=|watch\?.+&v=))((\w|-){11})(?:\S+)?$/)) {
        document.getElementById("errorMessage").innerHTML = "It is not a YouTube link!";
        linkBox.style.backgroundColor = "red";
        return false
    }

    var url = "../php/API.php?command=addMovie&title=" + title + "&description=" + description + "&categoryCode=" + categoryCode + "&link=" + link;
    createAjax(url);
    titleBox.value = "";
    descriptionBox.value = "";
    linkBox.value = "";
    categoryCodeSelect.value = categoryCodeSelect.children[0].value;
}

//Edit movie detalis in the playlist by modal
function EditMovieDetailByModal(el) {

    var processData = function () {
        document.getElementById("titleEdit").value = "";
        document.getElementById("descriptionEdit").value = "";
        document.getElementById("linkEdit").value = "";

        document.getElementById("titleEdit").style.background = "";
        document.getElementById("descriptionEdit").style.background = "";
        document.getElementById("linkEdit").style.background = "";
        document.getElementById("errorMessage").innerHTML = "";

        var valueInTd = "moviesIDHidden";
        var movieIdValue = findThisRowInThePlaylist(el, valueInTd);
        document.getElementById("moviesIDHidden").value = movieIdValue;

        //get the selected details movie from the playlist 

        var valueInTd = "title";
        var titleValue = findThisRowInThePlaylist(el, valueInTd);

        var valueInTd = "description";
        var descriptionValue = findThisRowInThePlaylist(el, valueInTd);

        var valueInTd = "categoryCode";
        var categoryCodeText = findThisRowInThePlaylist(el, valueInTd);

        var valueInTd = "link";
        var linkValue = findThisRowInThePlaylist(el, valueInTd);

        // Display the the selected details movie in the modal
        var select = document.getElementById("categoryCode");


        for (i = 0; i < select.length; i++) {
            if (select.options[i].text == categoryCodeText) {
                select.options[i].setAttribute("selected", "");
            } else {
                select.options[i].removeAttribute("selected");
            }
        }

        document.getElementById("titleEdit").value = titleValue;
        document.getElementById("descriptionEdit").value = descriptionValue;
        document.getElementById("linkEdit").value = linkValue;
    }

    getCategoriesMoviesTable(processData);
}

//delete movie from the playlist
function deleteMovieRow(el) {

    var confirmDeletion = confirm("Do you want to delete it?");
    if (!confirmDeletion) {
        return false;
    }
    var movieIdValue = findThisRowInThePlaylist(el, "moviesIDHidden");
    var url = "../php/API.php?command=deleteMovieRow&id=" + movieIdValue;
    createAjax(url);
}

//Find the specific <tr> in the playlist
function findThisRowInThePlaylist(el, valueInTd) {
    var tr = el.closest(".playlistRow");
    var td = tr.childNodes;

    var currentValue = find(td, valueInTd);
    return currentValue;
}

//Find the specific <td> in the <tr> in the playlist by class name
function find(currObj, value) {
    for (var i = 0; i < currObj.length; i++) {
        if ((currObj[i].className == value) && (value == "link")) {

            var currValue = currObj[i].children[0].id;

        } else if (currObj[i].className == value) {

            var currValue = currObj[i].innerHTML;
        }
    }
    return currValue;
}

//edit the movie details by clicking on button in the Edit-modal
function editMovieRow() {
    var moviesIDHiddenBox = document.getElementById("moviesIDHidden");
    var titleBox = document.getElementById("titleEdit");
    var descriptionBox = document.getElementById("descriptionEdit");
    var categoryCodeSelect = document.getElementById("categoryCode");
    var linkBox = document.getElementById("linkEdit");

    var moviesIDHidden = moviesIDHiddenBox.value;
    var title = titleBox.value;
    var description = descriptionBox.value;
    var categoryCode = categoryCodeSelect.options[categoryCodeSelect.selectedIndex].value;
    var link = linkBox.value;

    document.getElementById("errorMessage").innerHTML = "";
    titleBox.style.backgroundColor = "";
    categoryCodeSelect.style.backgroundColor = "";
    linkBox.style.backgroundColor = "";

    if (!emptyInputValidation(titleBox, title, "Title")) {
        return false;
    }

    if (!emptyInputValidation(linkBox, link, "YouTube link")) {
        return false;
    }

    if (!link.match(/^(?:https?:\/\/)?(?:www\.)?(?:youtu\.be\/|youtube\.com\/(?:embed\/|v\/|watch\?v=|watch\?.+&v=))((\w|-){11})(?:\S+)?$/)) {
        document.getElementById("errorMessage").innerHTML = "it is not a YouTube link!";
        linkBox.style.backgroundColor = "red";
        return false;
    }


    var url = "../php/API.php?command=editMovieRow&title=" + title + "&moviesIDHidden=" + moviesIDHidden + "&description=" + description + "&categoryCode=" + categoryCode + "&link=" + link;
    createAjax(url);
}


//ajax of search in the playlist. only in Title and Description columns
function search() {

    var searchBox = document.getElementById("searchBox");
    var search = searchBox.value;
    var url = "../php/API.php?command=searchInPlaylist&search=" + search;
    ajax = new XMLHttpRequest();
    ajax.open("GET", url, true);
    ajax.send();
    ajax.onreadystatechange = createUI;
}

//move to iframe page by clicking on the youTube icon in the playlist table
function iframeLink(link) {
    window.open("iframe.php?" + link.id, "_self");
}

//put youTube link in the iframe
function dispalyIframe() {
    var url = window.location.href;
    var split = url.split('v=');
    var youtubeLink = split[1];
    document.getElementById("iframe").src = "https://www.youtube.com/embed/" + youtubeLink + "?autoplay=1";
}


//create the playlist table in playlist.php
function createUI() {

// ajax.readyState = 4 ==> Data got from the server:
    if (ajax.readyState == 4) {

// If there is no error:
        if (ajax.status == 200) {

// Convert AJAX string into a real array:
            if ((ajax.responseText != "undefined") && (ajax.responseText != "")) {
                var playlist = JSON.parse(ajax.responseText);

                var table = "<table id='tablePlaylist' class='table table-striped'><thead><tr><th scope='col'>#</th><th scope='col' class='moviesIDHidden'>MoviesID</th><th scope='col'>Title</th><th scope='col'>Description</th><th scope='col'>Category Name</th><th scope='col'>Play</th><th scope='col'>Edit</th><th scope='col'>Delete</th></tr></thead><tbody>";
                for (var i = 0; i < playlist.length; i++) {
                    var row = "<tr class='playlistRow'> <th scope='row'>" + parseInt(i + 1) +
                            "</th>" + "<td class='moviesIDHidden'>" + playlist[i].moviesID + "</td>" +
                            "</th>" + "<td class='title'>" + playlist[i].title + "</td>" +
                            "<td class='description'>" + playlist[i].description + "</td>" +
                            "<td class='categoryCode'>" + playlist[i].categoryCode + "</td>" +
                            "<td class='link'><a href='#' onclick='iframeLink(this)' id=" + playlist[i].link + "><span class='fab fa-youtube'></span></a></td>" +
                            "<td><a href='#' data-toggle='modal' data-target='#exampleModalCenter'><span onclick='EditMovieDetailByModal(this)' class='fas fa-pencil-alt'></span></a></td>" +
                            "<td><a href='#'><span onclick='deleteMovieRow(this)' class='fas fa-trash-alt'></span></a></td>" + "</tr>";
                    table += row;
                }

                table += "</tbody></table>";
                document.getElementById("playlistDispaly").innerHTML = table;
            }
        } else {
            alert(ajax.status + " --> " + ajax.statusText);
        }
    }
}

//Error messsage by the server when using AJAX
function createUIMessage() {

    if (ajax.readyState == 4) {
        if (ajax.status == 200) {

            if ((ajax.responseText != "undefined") && (ajax.responseText != "")) {

                var error = JSON.parse(ajax.responseText);
                document.getElementById("errorMessage").innerHTML = error.error;  

            } else {

                $("[data-dismiss=modal]").trigger({type: "click"});
                getPlaylist();
            }
        } else {
            alert(ajax.status + " --> " + ajax.statusText);
        }
    }
}

function createAjax(url) {
    ajax = new XMLHttpRequest();
    ajax.open("GET", url, true);
    ajax.send();
    ajax.onreadystatechange = createUIMessage;
}

//validation when register
function registerValidation() {
    var firstNameBox = document.getElementById("firstNameBox");
    var lastNameBox = document.getElementById("lastNameBox");
    var usernameBox = document.getElementById("usernameBox");
    var passwordBox = document.getElementById("passwordBox");

    var firstName = firstNameBox.value;
    var lastName = lastNameBox.value;
    var username = usernameBox.value;
    var password = passwordBox.value;

    document.getElementById("errorMessage").innerHTML = "";
    firstNameBox.style.backgroundColor = "";
    lastNameBox.style.backgroundColor = "";
    usernameBox.style.backgroundColor = "";
    passwordBox.style.backgroundColor = "";

    if (!emptyInputValidation(firstNameBox, firstName, "first name")) {
        return false;
    }

    if (!emptyInputValidation(lastNameBox, lastName, "last name")) {
        return false;
    }

    if (!emptyInputValidation(usernameBox, username, "username")) {
        return false;
    }

    if (!emptyInputValidation(passwordBox, password, "password")) {
        return false;
    }
    return true;
}

//validation when log-in
function loginValidation() {
    var usernameBox = document.getElementById("usernameBox");
    var passwordBox = document.getElementById("passwordBox");
    var username = usernameBox.value;
    var password = passwordBox.value;


    document.getElementById("errorMessage").innerHTML = "";

    usernameBox.style.backgroundColor = "";
    passwordBox.style.backgroundColor = "";

    if (!emptyInputValidation(usernameBox, username, "username")) {
        return false;
    }

    if (!emptyInputValidation(passwordBox, password, "password")) {
        return false;
    }

    return true;
}


function emptyInputValidation(valueBox, value, param) {
    if ((value == "") || (value == null)) {
        document.getElementById("errorMessage").innerHTML = "Missing " + param + "!";
        valueBox.style.backgroundColor = "red";
        return false
    }
    return true;
}

//Automatic play music in the home page
function playAudio() {
    var audio = document.getElementById("audio");
    var musicButton = document.getElementById("musicButton");

    if (audio.paused) {
        audio.play();
        musicButton.removeAttribute("class", "far fa-play-circle btn btn-success");
        musicButton.setAttribute("class", "far fa-pause-circle btn btn-danger");

    } else {
        audio.pause();
        musicButton.removeAttribute("class", "far fa-pause-circle btn btn-danger");
        musicButton.setAttribute("class", "far fa-play-circle btn btn-success");
    }
}









