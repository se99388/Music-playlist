<?php
session_start();
if (isset($_SESSION["username"])) {
    $username = $_SESSION["username"];
} else {
    $username = null;
}
?>
<!DOCTYPE html>
<!--
To change this license header, choose License Headers in Project Properties.
To change this template file, choose Tools | Templates
and open the template in the editor.
-->
<html>
    <head>
        <meta charset="UTF-8">
        <title></title>
        <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.1.3/css/bootstrap.min.css" integrity="sha384-MCw98/SFnGE8fJT3GXwEOngsV7Zt27NXFoaoApmYm81iuXoPkFOJwJ8ERdknLPMO" crossorigin="anonymous">
        <script src="https://code.jquery.com/jquery-3.3.1.slim.min.js" integrity="sha384-q8i/X+965DzO0rT7abK41JStQIAqVgRVzpbzo5smXKp4YfRvH+8abtTE1Pi6jizo" crossorigin="anonymous"></script>
        <script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.14.3/umd/popper.min.js" integrity="sha384-ZMP7rVo3mIykV+2+9J3UJ46jBk0WLaUAdn689aCwoqbBJiSnjAK/l8WvCWPIPm49" crossorigin="anonymous"></script>
        <script src="https://stackpath.bootstrapcdn.com/bootstrap/4.1.3/js/bootstrap.min.js" integrity="sha384-ChfqqxuZUCnJSK3+MXmPNIyE6ZbWh2IMqE241rYiqJxyMiZ6OW/JmZQ5stwEULTy" crossorigin="anonymous"></script>
        <link href="https://fonts.googleapis.com/css?family=Gamja+Flower" rel="stylesheet">
        <link rel="stylesheet" href="https://use.fontawesome.com/releases/v5.5.0/css/all.css" integrity="sha384-B4dIYHKNBt8Bc12p+WXckhzcICo0wtJAoU8YZTY5qE0Id1GSseTk6S+L3BlXeVIU" crossorigin="anonymous">
        <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.3.1/jquery.min.js"></script>
        <link rel="stylesheet" href="../css/style.css">
        <script src="../js/index.js"></script>

    </head>
    <body onload="getPlaylist()" id="playlistBody">
        <br>
        <div class="container-fluid">
            <?php
            if ($username == null) {
                header("location:../homePage.php");
            } else {
                echo "Hello $username | <a href='../homePage.php'>Home Page</a> | <a href='logout.php'>Log-out</a>";
            }
            ?>

            <div class="row">
                <div class="input-group mb-3 col-2">
                    <div class="input-group-prepend">
                        <span class="input-group-text">Search</span>
                    </div>
                    <input type="search" id="searchBox" class="form-control" placeholder="" aria-label="Example text with button addon" aria-describedby="button-addon1" onkeyup="search()">

                </div>
                <div class="col-8">
                    <h2>fill in your playlist in the table below</h2>
                </div>
                <div class="col-2">

                    <a href="addMovie.php" class="btn btn-success">
                        +
                    </a>
                </div>
            </div>
            <div class="row">
                <div id="playlistDispaly" class="col-11">

                </div>
            </div>
        </div>



        <!-- Modal -->
        <div class="modal fade" id="exampleModalCenter" tabindex="-1" role="dialog" aria-labelledby="exampleModalCenterTitle" aria-hidden="true" data-backdrop='static'>
            <div class="modal-dialog modal-dialog-centered" role="document">
                <div class="modal-content">
                    <div class="modal-header">
                        <h5 class="modal-title" id="exampleModalCenterTitle">Edit Your Playlist</h5>
                        <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                            <span aria-hidden="true">&times;</span>
                        </button>
                    </div>
                    <div class="modal-body">
                        <div class="row">
                            <div class="form-group col-5 moviesIDHidden">
                                <input type="text" class="form-control" id="moviesIDHidden" >
                            </div>
                            <div class="form-group col-5">
                                <label>Title</label>
                                <input type="text" class="form-control" id="titleEdit" placeholder="Enter Title Movie">
                            </div>

                            <div class="form-group col-8">
                                <label>Description</label>
                                <input type="text" class="form-control" id="descriptionEdit" placeholder="Enter Description Of Your Movie">
                            </div>
                        </div>

                        <div class="row">
                            <div class="form-group col-5">
                                <select class="custom-select" id="categoryCode" >

                                </select> </div>
                        </div>
                        <div class="row">
                            <div class="form-group col-12">
                                <label>Link</label>
                                <input type="text" class="form-control" id="linkEdit" placeholder="Enter Link Movie">
                            </div>
                        </div>
                        <div id="errorMessage">

                        </div>
                    </div>
                    <div class="modal-footer">
                        <button id="closeButton" type="button" class="btn btn-secondary" data-dismiss="modal">Close</button>
                        <button id="submitButton" type="submit" class="btn btn-primary" onclick="editMovieRow()">Save the changes</button>
                    </div>
                </div>
            </div>
        </div>

    </body>
</html>
