<?php
session_start();
if (isset($_SESSION["username"])) {
    $username = $_SESSION["username"];
} else {
    $username = null;
}
?>
<!DOCTYPE html>

<html>
    <head>
        <meta charset="UTF-8">
        <title></title>
        <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.1.3/css/bootstrap.min.css" integrity="sha384-MCw98/SFnGE8fJT3GXwEOngsV7Zt27NXFoaoApmYm81iuXoPkFOJwJ8ERdknLPMO" crossorigin="anonymous">
        <link rel="stylesheet" href="https://use.fontawesome.com/releases/v5.5.0/css/all.css" integrity="sha384-B4dIYHKNBt8Bc12p+WXckhzcICo0wtJAoU8YZTY5qE0Id1GSseTk6S+L3BlXeVIU" crossorigin="anonymous">
        <link href="https://fonts.googleapis.com/css?family=Gamja+Flower" rel="stylesheet">
        <link rel="stylesheet" href="../css/style.css">
        <script src="../js/index.js"></script>
    </head>
    <body onload="getCategoriesMoviesTable()" id="playlistBody">
        <br>
        <div class="container-fluid">
            <?php
            if ($username == null) {
                header("location:../homePage.php");
            } else {
                echo "Hello $username | <a href='../homePage.php'>Home Page</a> | <a href='logout.php'>Log-out</a>";
            }
            ?>
            <div class="row links">
                <div class="col">
                    <a href="playlist.php" class="badge badge-primary">Back to my Playlist</a>
                </div>
            </div>

            <div class="row addMovieMainPage">

                <div class="form-group col-3">
                    <label>Title</label>
                    <input type="text" class="form-control" id="title" placeholder="Enter Title Movie">
                </div>

                <div class="form-group col-3">
                    <label>Description</label>
                    <input type="text" class="form-control" id="description" placeholder="Enter Description Of Your Movie">
                </div>

                <div class="form-group col-3">
                    <label>Category name</label>
                    <div class="input-group mb-3">
                        <div class="input-group-prepend">
                            <label class="input-group-text" for="inputGroupSelect01">Options</label>
                        </div>
                        <select class="custom-select" id="categoryCode" >
                            <option selected disabled>Choose...</option>
                        </select>
                    </div>

                </div>

                <div class="form-group col-3">
                    <label>Link</label>
                    <input type="text" class="form-control" id="link" placeholder="Enter Link Movie">
                </div>

                <div class="col">
                    <button type="submit" class="btn btn-primary" onclick="addMovieToPlaylist()">Add a new movie to your playlist</button>
                    <br>
                    <br>
                    <a href="https://www.youtube.com/?hl=iw&gl=IL" target="_blank"><span class='fab fa-youtube'>Click here to open YouTube</span></a>
                </div>
            </div>

            <div id="errorMessage">

            </div>
        </div>

    </body>
</html>
