<?php
session_start();
if (isset($_SESSION["username"])) {
    $username = $_SESSION["username"];
} else {
    $username = null;
}
?>
<!DOCTYPE html>
<!--
To change this license header, choose License Headers in Project Properties.
To change this template file, choose Tools | Templates
and open the template in the editor.
-->
<html>
    <head>
        <meta charset="UTF-8">
        <title></title>
        <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.1.3/css/bootstrap.min.css" integrity="sha384-MCw98/SFnGE8fJT3GXwEOngsV7Zt27NXFoaoApmYm81iuXoPkFOJwJ8ERdknLPMO" crossorigin="anonymous">
        <link rel="stylesheet" href="https://use.fontawesome.com/releases/v5.5.0/css/all.css" integrity="sha384-B4dIYHKNBt8Bc12p+WXckhzcICo0wtJAoU8YZTY5qE0Id1GSseTk6S+L3BlXeVIU" crossorigin="anonymous">
        <link href="https://fonts.googleapis.com/css?family=Gamja+Flower" rel="stylesheet">
        <link rel="stylesheet" href="../css/style.css">
        <script src="../js/index.js"></script>
    </head>
    <body onload="dispalyIframe()" id="playlistBody">
        <br>
        <div class="container-fluid">
            <?php
            if ($username == null) {
                header("location:../homePage.php");
            } else {
                echo "Hello $username | <a href='playlist.php'>My Playlist</a> | <a href='logout.php'>Log-out</a>";
            }
            ?>
            <div class="row links">
                <div class="col">
                    <a href="playlist.php" class="badge badge-primary">Back to my Playlist</a>
                </div>
            </div>

            <br>
            <div class="row">

                <iframe id="iframe" width="560" height="315" src="" 
                        frameborder="0" allow="accelerometer; autoplay; encrypted-media; gyroscope; picture-in-picture" allowfullscreen autoplay="true"></iframe>

            </div>

        </div>
        <?php
        // put your code here
        ?>
    </body>
</html>
