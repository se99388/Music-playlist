<?php
session_start();
if (isset($_SESSION["username"])) {
    $username = $_SESSION["username"];
} else {
    $username = null;
}
?>

<!DOCTYPE html>
<!--
To change this license header, choose License Headers in Project Properties.
To change this template file, choose Tools | Templates
and open the template in the editor.
-->
<html>
    <head>
        <meta charset="UTF-8">
        <title></title>
        <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.1.3/css/bootstrap.min.css" integrity="sha384-MCw98/SFnGE8fJT3GXwEOngsV7Zt27NXFoaoApmYm81iuXoPkFOJwJ8ERdknLPMO" crossorigin="anonymous">
        <link rel="stylesheet" href="https://use.fontawesome.com/releases/v5.5.0/css/all.css" integrity="sha384-B4dIYHKNBt8Bc12p+WXckhzcICo0wtJAoU8YZTY5qE0Id1GSseTk6S+L3BlXeVIU" crossorigin="anonymous">
        <link href="https://fonts.googleapis.com/css?family=Gamja+Flower" rel="stylesheet">

        <link rel="stylesheet" href="../css/style.css">
        <script src="../js/index.js"></script>
    </head>
    <body id="hompePageBody">

        <div class="container-fluid">
            <?php
            if ($username == null) {
                echo "Hello Guest | <a href='login.php'>Log-in</a> | <a href='../homePage.php'>Home Page</a>";
            } else {
                echo "Hello $username | <a href='html/playlist.php'>My Playlist</a> | <a href='html/logout.php'>Log-out</a>";
            }
            ?>
            <div class="row" >
                <div class="col-12" id="mainPageTitle">
                    <h1 id="head">My private Playlist</h1>
                </div>
            </div>
            <div class="row" id="mainPage" >
                <div class="col-12 center" >
                    <p>My private Playlist is the best place to create a playlist with any YouTube link </p>
                </div>
                <div class="offset-md-3 col-6 center" id="homePageForm">
                    <form action="../php/API.php" method="POST" id="loginForm" >
                        <div class="form-group">
                            <label >Enter your first name</label>
                            <input type="text" class="form-control" name="firstName" placeholder="first name" id="firstNameBox">
                        </div>
                        <div class="form-group">
                            <label >Enter your last name</label>
                            <input type="text" class="form-control" name="lastName" placeholder="last name" id="lastNameBox">
                        </div>
                        <div class="form-group">
                            <label >Enter new username</label>
                            <input type="text" class="form-control" name="username" placeholder="username" id="usernameBox">
                        </div>
                        <div class="form-group">
                            <label for="exampleDropdownFormPassword2">Enter new password</label>
                            <input type="password" class="form-control" name="password" placeholder="Password" id="passwordBox">
                        </div>

                        <input type="hidden" name="command" value="register">
                        <button type="submit" class="btn btn-primary" onclick="return registerValidation()">Register</button>
                    </form>
                    <div id="errorMessage">
                        <?php
                        if (isset($_SESSION["error_message"])) {
                            echo $_SESSION["error_message"];
                            unset($_SESSION['error_message']);
                        }
                        ?>
                    </div>
                </div>
            </div>
        </div>  

    </body>
</html>
