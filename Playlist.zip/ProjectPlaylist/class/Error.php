<?php

class ErrorMessage {
    public $error;
     public $status;
    
    public function __construct($error, $status) {
        $this->error = $error;
        $this->status = $status;
       
    }

}
