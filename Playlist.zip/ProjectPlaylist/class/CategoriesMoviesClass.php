<?php

class CategoriesMovies {

    public $categoryCode;
    public $categoryName;
   

    public function __construct($categoryCode, $categoryName) {
        $this->categoryCode = $categoryCode;
        $this->categoryName = $categoryName;
    }

}
