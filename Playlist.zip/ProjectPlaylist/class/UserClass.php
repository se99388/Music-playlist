<?php

class User {

    public $userID;
    public $firstname;
    public $lastname;
    public $username;
    public $password;

    public function __construct($userID, $firstname, $lastname, $username, $password) {
        $this->userID = $userID;
        $this->lastname = $lastname;
        $this->username = $username;
        $this->password = $password;
        $this->firstname = $firstname;
    }

}
