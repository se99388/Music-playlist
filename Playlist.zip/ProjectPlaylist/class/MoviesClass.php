<?php

class Movies {

    public $moviesID;
    public $title;
    public $description;
    public $categoryCode;
    public $link;

    public function __construct($moviesID, $title, $description, $categoryCode, $link) {
        $this->moviesID = $moviesID;
        $this->title = $title;
        $this->description = $description;
        $this->categoryCode = $categoryCode;
        $this->link = $link;
    }

}
