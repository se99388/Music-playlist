<?php

require_once 'DAL.php';
require_once '..\class\MoviesClass.php';
require_once '..\class\UserClass.php';
require_once '..\class\CategoriesMoviesClass.php';

//get all the playlist based on userID
function getPlaylist($userID) {

    $sql = "SELECT MovieID, Title, Description, categoryName, Link FROM movies join categorycodemovies WHERE movies.CategoryCode=categorycodemovies.categoryCodeID AND UserID = '$userID' ORDER BY MovieID ASC";

    $allMovies = select($sql);
    $oopAllMovies = array();
    foreach ($allMovies as $el) {
        $oopAllMovies[] = new Movies($el->MovieID, $el->Title, $el->Description, $el->categoryName, $el->Link);
    }
    return $oopAllMovies;
}

//adding new movie to the DB
function addMovie($userID, $title, $description, $categoryCode, $link) {
    $title = addslashes($title);
    $description = addslashes($description);
    $link = addslashes($link);
    
    $sql = "insert into movies(UserID, Title, Description, CategoryCode, Link) " . "values('$userID', '$title', '$description', '$categoryCode', '$link')";
    execute($sql);
}

//delete movie from the DB
function deleteMovie($movieID) {
    $sql = "delete from movies where MovieID = '$movieID'";
    execute($sql);
}
//edit movie details
function editMovie($titleName, $value, $movieID) {
    $value = addslashes($value);
    $sql = "update movies set $titleName='$value' where MovieID = '$movieID'";
    execute($sql);
}

//Create new user
function addUser($firstName, $lastName, $username, $password) {

    $firstName = addslashes($firstName);
    $lastName = addslashes($lastName);
    $username = addslashes($username);
    $password = addslashes($password);

    $password = sha1($password);

    $sql = "insert into users(FirstName, LastName, UserName, Password) values('$firstName', '$lastName', '$username', '$password')";
    execute($sql);
}

//check if username is already exists
function checkExistUsername($username) {
    $username = addslashes($username);
    $sql = "SELECT COUNT(*) as totalUsernames FROM `users` WHERE UserName = '$username'";
    $count = getObject($sql);
    return $count->totalUsernames > 0;
}

//search in the Title or Descripiton in the playlist
function searchInPlaylist($userID, $search) {
    $search = addslashes($search);
    $sql = "SELECT MovieID, Title, Description, categoryName, Link FROM movies join categorycodemovies WHERE movies.CategoryCode=categorycodemovies.categoryCodeID AND UserID = '$userID' AND (Title LIKE '%$search%' OR Description LIKE '%$search%')";
    $allMovies = select($sql);
    $oopAllMovies = array();
    foreach ($allMovies as $el) {
        $oopAllMovies[] = new Movies($el->MovieID, $el->Title, $el->Description, $el->categoryName, $el->Link);
    }
    return $oopAllMovies;
}

//getting all username details (but display in the session the username only)
function getUserDetail($username, $password) {
    $username = addslashes($username);
    $password = addslashes($password);
    
    $password = sha1($password);
    $sql = "SELECT UserID, FirstName, LastName, UserName, Password FROM `users` WHERE UserName = '$username' AND Password = '$password'";

    $userDetail = select($sql);
    $oopUserDetail = array();
    foreach ($userDetail as $el) {
        $oopUserDetail[] = new User($el->UserID, $el->FirstName, $el->LastName, $el->UserName, $el->Password);
    }

    return $oopUserDetail;
}

//getting all the categories movies from the DB
function getCategoriesMoviesTable() {

    $sql = "SELECT categoryCodeID, categoryName FROM categorycodemovies ORDER BY categoryCodeID ASC";

    $categoriesMoviesTable = select($sql);
    $oopCategoriesMoviesTable = array();
    foreach ($categoriesMoviesTable as $el) {
        $oopCategoriesMoviesTable[] = new CategoriesMovies($el->categoryCodeID, $el->categoryName);
    }
    return $oopCategoriesMoviesTable;
}

