<?php

session_start();
if (isset($_SESSION["userId"])) {
    $userId = $_SESSION["userId"];
} else {
    $userId = null;
}

require_once 'BLL.php';
require_once '..\class\Error.php';

if (($_REQUEST["command"] != null) && isset($_REQUEST["command"])) {


    $command = $_REQUEST["command"];

    switch ($command) {

        case "getCategoriesMoviesTable":
            $CategoriesMoviesTable = getCategoriesMoviesTable();
            displayJSON($CategoriesMoviesTable);
            break;

        case "getPlaylist":
            $playlist = getPlaylist($userId);
            displayJSON($playlist);
            break;

        case "searchInPlaylist":
            $search = $_GET["search"];
            $searchInPlaylist = searchInPlaylist($userId, $search);
            displayJSON($searchInPlaylist);
            break;

        case "addMovie":

            if (($_GET["title"] != null) && (isset($_GET["title"]))) {
                $title = $_GET["title"];
            } else {
                $error = new ErrorMessage("Title is missing", 400);
                displayJSON($error);
                break;
            }

            if (($_GET["categoryCode"] != "Choose...")) {
                $categoryCode = $_GET["categoryCode"];
            } else {
                $error = new ErrorMessage("Category name is missing", 400);
                displayJSON($error);
                break;
            }
            if (($_GET["description"] != null) && (isset($_GET["description"]))) {
                $description = $_GET["description"];
            } else {
                $description = null;
            }
            
            if (($_GET["link"] != null) && (isset($_GET["link"]))) {
                $link = $_GET["link"];
                if (!preg_match("/^(?:https?:\/\/)?(?:www\.)?(?:youtu\.be\/|youtube\.com\/(?:embed\/|v\/|watch\?v=|watch\?.+&v=))((\w|-){11})(?:\S+)?$/", $link)) {
                    $error = new ErrorMessage("It has to be a YouTube link", 400);
                    displayJSON($error);
                    break;
                }
            } else {
                $error = new ErrorMessage("Link is missing", 400);
                displayJSON($error);
                break;
            }

            addMovie($userId, $title, $description, $categoryCode, $link);
            $error = new ErrorMessage("Movie was just added", 200);
            displayJSON($error);
            break;

        case "deleteMovieRow":

            if (($_GET["id"] != null) && (isset($_GET["id"]))) {
                $id = $_GET["id"];
            } else {
                $error = new ErrorMessage("ID is missing", 400);
                displayJSON($error);
                break;
            }
            deleteMovie($id);
            break;

        case "editMovieRow":
            
            if (($_GET["moviesIDHidden"] != null) && (isset($_GET["moviesIDHidden"]))) {
                $movieId = $_GET["moviesIDHidden"];
            } else {
                $error = new ErrorMessage("Movie ID is missing", 400);
                displayJSON($error);
                break;
            }
            if (($_GET["title"] != null) && (isset($_GET["title"]))) {
                $title = $_GET["title"];
                editMovie('Title', $title, $movieId);
            } else {
                $error = new ErrorMessage("Title is missing", 400);
                displayJSON($error);
                break;
            }
            if (($_GET["description"] != null) || (isset($_GET["description"]))) {
                $description = $_GET["description"];
                editMovie('Description', $description, $movieId);
            }

            if (($_GET["categoryCode"] != null) && (isset($_GET["categoryCode"]))) {
                $categoryCode = $_GET["categoryCode"];
                editMovie('CategoryCode', $categoryCode, $movieId);
            }
            if (($_GET["link"] != null) && (isset($_GET["link"]))) {
                $link = $_GET["link"];
                if (!preg_match("/^(?:https?:\/\/)?(?:www\.)?(?:youtu\.be\/|youtube\.com\/(?:embed\/|v\/|watch\?v=|watch\?.+&v=))((\w|-){11})(?:\S+)?$/", $link)) {
                    $error = new ErrorMessage("It has to be a YouTube link", 400);
                    displayJSON($error);
                    break;
                }
            } else {
                $error = new ErrorMessage("Link is missing", 400);
                displayJSON($error);
                break;
            }

            editMovie('Link', $link, $movieId);
            break;

        case "logIn":
            
            if (($_POST["username"] == null) || (!isset($_POST["username"]))) {
                $_SESSION["error_message"] = "missing_username";
                header("location:../html/login.php");

                break;
            }
            $username = $_POST["username"];

            if (($_POST["password"] == null) || (!isset($_POST["password"]))) {
                $_SESSION["error_message"] = "missing_password";
                header("location:../html/login.php");
                break;
            }
            $password = $_POST["password"];

            $userDetail = getUserDetail($username, $password);
            if ($userDetail == null) {
                $_SESSION["error_message"] = "Wrong username or password";
                header("location:../html/login.php");
                break;
            } else {
                foreach ($userDetail as $el) {
                    $oopUserDetail[] = new User($el->userID, $el->firstname, $el->lastname, $el->username, $el->password);
                    $userId = $el->userID;
                    $firstname = $el->firstname;
                    $lastname = $el->lastname;
                    $username = $el->username;
                    $password = $el->password;
                }
                $_SESSION["username"] = $username;
                $_SESSION["password"] = $password;
                $_SESSION["userId"] = $userId;
                header("location:../html/playlist.php");
            }
            break;

        case "register":
            
            if (($_POST["firstName"] == null) || (!isset($_POST["firstName"]))) {
                $_SESSION['error_message'] = 'missing_firstname';
                header("location:../html/register.php");
                break;
            }
            if (($_POST["lastName"] == null) || (!isset($_POST["lastName"]))) {
                $_SESSION['error_message'] = 'missing_lastname';
                header("location:../html/register.php");
                break;
            }
            if (($_POST["username"] == null) || (!isset($_POST["username"]))) {
                $_SESSION['error_message'] = 'missing_username';
                header("location:../html/register.php");
                break;
            }
            if (($_POST["password"] == null) || (!isset($_POST["password"]))) {
                $_SESSION['error_message'] = 'missing_password';
                header("location:../html/register.php");
                break;
            }
            $username = $_POST["username"];
            if (checkExistUsername($username)) {
                $_SESSION['error_message'] = 'This username is already exist!';
                header("location:../html/register.php");
                break;
            }
            $password = $_POST["password"];
            $lastName = $_POST["lastName"];
            $firstName = $_POST["firstName"];
            addUser($firstName, $lastName, $username, $password);
            header("location:../html/thanks.php");
            break;
    }
}

function displayJSON($obj) {
    $json = json_encode($obj);
    echo $json;
}
